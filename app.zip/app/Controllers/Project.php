<?php

namespace App\Controllers;
use App\Models\ProjectModel;

class Project extends BaseController
{
	public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger){
		// Do Not Edit This Line
		parent::initController($request, $response, $logger);
		header("Access-Control-Allow-Origin: * ");
		header("Access-Control-Allow-Methods: *");
		header("Access-Control-Allow-Headers: * ");
        $this->model = new ProjectModel();
   
	}
	function __construct(){
                    
        helper(['url', 'form']);          
     }

	public function index()
	{    
        return view('main_content');
	} 
	
    public function pro_add()
	{		
		echo view('admin/project/proadd');
	}

   
    public function pro_insert()
    {
//      			validation 				updated_by	
             
//                    pro_id									created_at	updated_by

                $pro=new ProjectModel();   											     
                $data=[
                    'project_no'=>$this->request->getPost('projectno'),
                    'cnt_id'=>$this->request->getPost('clientno'),
                    'owner_company_name'=>$this->request->getPost('companyname'),
                    'project_title'=>$this->request->getPost('projecttitle'),
                    'work_order_satus'=>$this->request->getPost('workstatus'),
                    'starting_date'=>$this->request->getPost('sdate'),
                    'complation_date'=>$this->request->getPost('cdate'),
                    'days_compated'=>$this->request->getPost('daycomplate'),   
                    'days_remaining'=>$this->request->getPost('dayremaining'),
                    'pro_status'=>$this->request->getPost('projectstatus'),
                    'sub_ctr_code'=>$this->request->getPost('code'),
                    'sub_ctr_name'=>$this->request->getPost('name'),
                    'project_expens'=>$this->request->getPost('projectexpens'),
                    'total_revenue'=>$this->request->getPost('projectrevenue'),
                    'profit_loss'=>$this->request->getPost('profitloss'),
                    'created_at'=>date('Y-m-d H:i:s'),
                ];

                $pro->insert($data);
				//  print_r($data); 

			  $session = session();
			$this->session->setFlashdata('success','Clent Record insert succesfully');
            return redirect('Pro/pro_form');
                            
    }
     public function search_client()
    {
       
    // public function search_account_mill_data($post)
    // {
        $cnt=new ProjectModel();   											     

        // $db = $this->db;
        // $db->setDatabase(session('DataSource'));
        // $gl_ids = gl_list([35]);
        // $gl_ids[]=35;
        $request= service('request');
        $postdata=$request->getPost('clientno');
        $response=array();

         $cnt->table('project');
        $getdata=$cnt->select('cnt_id,owner_company_name')
        ->findall();
        // $builder->where(array('is_delete' => '0'  ));        
        // $builder->whereIn('gl_group',$gl_ids);        
        // $builder->like('name',(@$post['searchTerm']) ? @$post['searchTerm'] : 'A');
        // $builder->limit(5);
        
        // $query = $cnt->get();
        // $getdata = $query->getResultArray();

        $data = array();
        foreach($getdata as $row){
            $data[] = array("id" => $row['owner_company_name']
                    // "text" => $row['owner_company_name']
                );
        }
        $response['data']=$data;
        return $this->response->setJSON($response);
    
    }
    public function pro_form()
	{		
        $pro=new ProjectModel();   		
        $data['project']=$pro->findall();
		echo view('admin/project/proshow',$data);
		
	}
    public function pro_profile($id)
    {

                $pro=new ProjectModel();   		
        $pro_id=$pro->where('pro_id',$id);
        //$emp_id=$emp->where('emp_id',$id);
        
        $data['pro_profile']=$pro->find($pro_id);
        echo view('admin/project/pro_profile',$data);
    }
  //'picture'=>['required'=>'First Shop Name Required...'
// 'exact_length[10]'=>'Mobile nimber must be a  digit.'

    public function delete($id)
    {
        $cnt=new ProjectModel();   											     
        $cnt->where('pro_id',$id)->delete();
        $session = session();
		$session->setFlashdata('success','Client record delete succesfully');
        return redirect('Pro/pro_form');

    }
    public function edit($id)
    {
        $cnt = new ProjectModel();
        $data['row']=$cnt->where('pro_id',$id)->first();
        return view('admin/project/proedit',$data);

    }
    public function update($id='')
    {
        
    
        
        $cnt=new ClientModel();   
        $cnt->find($id);   											     

            $data=[
                'project_no'=>$this->request->getPost('projectno'),
                'cnt_id'=>$this->request->getPost('clientno'),
                'owner_company_name'=>$this->request->getPost('companyname'),
                'project_title'=>$this->request->getPost('projecttitle'),
                'work_order_satus'=>$this->request->getPost('workstatus'),
                'starting_date'=>$this->request->getPost('sdate'),
                'complation_date'=>$this->request->getPost('cdate'),
                'days_compated'=>$this->request->getPost('daycomplate'),   
                'days_remaining'=>$this->request->getPost('dayremaining'),
                'pro_status'=>$this->request->getPost('projectstatus'),
                'sub_ctr_code'=>$this->request->getPost('code'),
                'sub_ctr_name'=>$this->request->getPost('name'),
                'project_expens'=>$this->request->getPost('projectexpens'),
                'total_revenue'=>$this->request->getPost('projectrevenue'),
                'profit_loss'=>$this->request->getPost('profitloss'),
                'updated_by'=>date('Y-m-d H:i:s'),
            ];

        $cnt->update($id,$data); 
        //  print_r($data); 
    
       
        //  print_r($data); 
            
				$session = session();
				$session->setFlashdata('success','Project Data update succesfully');
            //    $data['action']=BASE('Usercontroller/update'.$id);
            return redirect('Pro/pro_form');

                 
    }



}

