<footer class="main-footer">
            <strong>Copyright &copy; 2021-2022 <a href="<?=BASE; ?>#">CODESMITH</a>.</strong> All rights reserved.
         </footer>